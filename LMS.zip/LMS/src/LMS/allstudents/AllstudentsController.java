/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package LMS.allstudents;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.*;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class AllstudentsController implements Initializable {

    @FXML
    private TableView<Students> tblStudent;
    @FXML
    private MenuItem cmEdit;
    @FXML
    private MenuItem cmDelete;
    @FXML
    private TableColumn<Students, String> colSID;
    @FXML
    private TableColumn<Students, String> colSname;
    @FXML
    private TableColumn<Students, String> colLname;
    @FXML
    private TableColumn<Students, String> colBranch;
    @FXML
    private TableColumn<Students, String> colCourse;
    @FXML
    private TableColumn<Students, String> colYear;
    @FXML
    private TableColumn<Students, String> colSemi;

    Students allStu;
    Connection conn;
    PreparedStatement pstm;
    ResultSet res;

    @FXML
    private TextField txtSearch;
    @FXML
    private MenuItem cmIssue;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        showAllStudents();
//        search();

    }

//    ===========================================================
    private void deleteStu(ActionEvent event) {
        try {
            if (tblStudent.getSelectionModel().getSelectedIndex() > -1) {

                int id = Integer.parseInt(tblStudent.getSelectionModel().getSelectedItem().getSid().getValueSafe());
                pstm = DBConnect.getPstm("DELETE FROM students WHERE SID = " + id);

                Optional<ButtonType> alt = Utils.getAlert(Alert.AlertType.CONFIRMATION, "DELETE", "Are you sure ?", "Do you want to delete this student premenetly ? ");
                if (alt.get() == ButtonType.OK) {

                    int del = pstm.executeUpdate();
                    if (del > 0) {
//                        boxHeader.setVisible(true);
                        Utils.alertIt(Alert.AlertType.INFORMATION, "DELETE", "SUCCESS", "The student premenently deleted!");
                        showAllStudents();

                    } else {
                        Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "Not Deleted", "Check your database conectivity");
                    }
                }
            }

        } catch (Exception ex) {
            if (ex.getMessage().contains("foreign key")) {
                Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "FAILED", "This studen is already have an issued book, First return the book and try again.");
            } else {
                System.out.println(ex);
            }

        }
    }

//    ---------------------------- Show all --------------------------
    public void showAllStudents() {
        ObservableList records = FXCollections.observableArrayList();
        try {

            pstm = DBConnect.getPstm("SELECT * FROM students");
            res = DBConnect.getResult();

            if (res.next()) {
                do {
                    allStu = new Students();
                    allStu.setSid(res.getString("SID"));
                    allStu.setName(res.getString("s_name"));
                    allStu.setLname(res.getString("s_lname"));
                    allStu.setBranch(res.getString("branch"));
                    allStu.setCourse(res.getString("course"));
                    allStu.setYear(res.getString("year"));
                    allStu.setSemis(res.getString("semister"));

                    records.addAll(allStu);

                } while (res.next());
                colSID.setCellValueFactory(e -> e.getValue().getSid());
                colSname.setCellValueFactory(e -> e.getValue().getName());
                colLname.setCellValueFactory(e -> e.getValue().getLname());
                colBranch.setCellValueFactory(e -> e.getValue().getBranch());
                colCourse.setCellValueFactory(e -> e.getValue().getCourse());
                colYear.setCellValueFactory(e -> e.getValue().getYear());
                colSemi.setCellValueFactory(e -> e.getValue().getSemis());
            }
            Utils.searchStudent(records, tblStudent, txtSearch);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    
    @FXML
    private void updateStud(ActionEvent event) {
        new Utils().showStage("Update student", "/LMS/editstudent/editstudent.fxml");
    }

    @FXML
    private void deleteStud(ActionEvent event) {
        try {
            if (tblStudent.getSelectionModel().getSelectedIndex() > -1) {
                int id = Integer.parseInt(tblStudent.getSelectionModel().getSelectedItem().getSid().getValueSafe());
                pstm = DBConnect.getPstm("DELETE FROM students WHERE SID = " + id);

                Optional<ButtonType> alt = Utils.getAlert(Alert.AlertType.CONFIRMATION, "DELETE", "Are you sure ?", "Do you want to delete this student  premenetly ? ");
                if (alt.get() == ButtonType.OK) {

                    int del = pstm.executeUpdate();
                    if (del > 0) {
//                        Utils.alertIt(Alert.AlertType.INFORMATION, "DELETE", "Deleted", "The student premenently deleted!");
                        showAllStudents();

                    } else {
                        Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "FAILED", "Check your database conectivity");
                    }
                }
            }

        } catch (Exception ex) {
            if (ex.getMessage().contains("foreign key")) {
                Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "Not Deleted", "This student already have an  issued book, First return the book and try again.");
            } else {
                System.out.println(ex);
            }

        }
    }

    @FXML
    private void searchStudent(ActionEvent event) {
        if (!txtSearch.getText().isEmpty()) {
            ObservableList<Students> search = FXCollections.observableArrayList();
            try {

                String name = txtSearch.getText();

                pstm = DBConnect.getPstm("SELECT * FROM students WHERE s_name LIKE  '" + name + "%'  OR s_lname LIKE '" + name
                        + "%' OR SID = 0");
                res = DBConnect.getResult();

                if (res.next()) {
                    do {
                        allStu = new Students();
                        allStu.setSid(res.getString("SID"));
                        allStu.setName(res.getString("s_name"));
                        allStu.setLname(res.getString("s_lname"));
                        allStu.setBranch(res.getString("branch"));
                        allStu.setCourse(res.getString("course"));
                        allStu.setYear(res.getString("year"));
                        allStu.setSemis(res.getString("semister"));

                        search.addAll(allStu);
                    } while (res.next());
                    colSID.setCellValueFactory(e -> e.getValue().getSid());
                    colSname.setCellValueFactory(e -> e.getValue().getName());
                    colLname.setCellValueFactory(e -> e.getValue().getLname());
                    colBranch.setCellValueFactory(e -> e.getValue().getBranch());
                    colCourse.setCellValueFactory(e -> e.getValue().getCourse());
                    colYear.setCellValueFactory(e -> e.getValue().getYear());
                    colSemi.setCellValueFactory(e -> e.getValue().getSemis());
                } else {
                    showAllStudents();
                }

                tblStudent.setItems(search);

            } catch (Exception ex) {
                System.out.println(ex);
            }

        } else {
            showAllStudents();
        }
    }

    @FXML
    private void issueBook(ActionEvent event) {
        new Utils().showStage("Issue Book", "/LMS/issue/issue.fxml");
    }

}

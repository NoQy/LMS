package LMS.main;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class MainController implements Initializable {

    @FXML
    private Button btnAddBook;
    @FXML
    private Button btnStatis;
    @FXML
    private Button btnIssue;
    @FXML
    private Button btnAllBook;
    @FXML
    private Button btnAddStudent;
    @FXML
    private Button btnAllStud;
    @FXML
    private Button btnReturn;
    Utils utils;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        utils = new Utils();
        DBConnect.getConn("lms2");
        
    }

    @FXML
    private void addBook(ActionEvent event) throws IOException {
        utils.showStage("Add New Book", "/LMS/addBook/add_book.fxml");
    }

    @FXML
    private void showStatis(ActionEvent event) {
                utils.showStage("Statistics", "/LMS/statistics/statis.fxml");

    }

    @FXML
    private void issue(ActionEvent event) {
                utils.showStage("Issue Book", "/LMS/issue/issue.fxml");

    }

    @FXML
    private void showAllBooks(ActionEvent event) {
        utils.showStage("All Book", "/LMS/allbook/allbook.fxml");
    }

    @FXML
    private void addStudent(ActionEvent event) {
        utils.showStage("Add New Student", "/LMS/addStudent/add_student.fxml");

    }

    @FXML
    private void showAllStudent(ActionEvent event) {
                utils.showStage("All Students", "/LMS/allstudents/allstudents.fxml");
    }

    @FXML
    private void returnBook(ActionEvent event) {
                utils.showStage("Return Book", "/LMS/returnBook/returnbook.fxml");

    }

}

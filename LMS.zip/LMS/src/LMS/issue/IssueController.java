package LMS.issue;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import java.sql.*;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class IssueController implements Initializable {

    @FXML
    private TextField txtSID;
    @FXML
    private TextField txtSname;
    private TextField txtSlname;
    @FXML
    private TextField txtBID;
    @FXML
    private TextField txtBname;
    @FXML
    private TextField txtBauthor;
    private TextField txtBpub;
    @FXML
    private TextField txtBprice;

    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    @FXML
    private Button btnSearch1;
    private TextField txtBranch;
    private TextField txtsemis;
    private TextField txtEdition;
    @FXML
    private Label lblMsg2;
    @FXML
    private Label lblMsg1;
    @FXML
    private HBox boxShowErr1;
    @FXML
    private HBox boxShowErr2;
    @FXML
    private DatePicker dtDate;
    @FXML
    private Button btnIssue;
    @FXML
    private Button btnSearch;
    @FXML
    private DatePicker dtDate2;
    @FXML
    private TextField txtSSearch;
    @FXML
    private TextField txtBSearch;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        txtBSearch.requestFocus();
        conn = DBConnect.getConn("lms2");
        boxShowErr1.setVisible(false);
        boxShowErr2.setVisible(false);

        dtDate.setValue(java.time.LocalDate.now());
        dtDate2.setValue(java.time.LocalDate.now());

    }

    @FXML
    private void searchBook(ActionEvent event) {
        try {
            if (!txtBSearch.getText().trim().isEmpty()) {

                String title = txtBSearch.getText();
                String qr = "SELECT * FROM books WHERE"
                        + " book_name LIKE '%" + title + "%'"
                        + " OR BID LIKE '" + title + "'"
                        + " OR author LIKE '" + title + "%'";

                Statement stm = conn.createStatement();
                res = stm.executeQuery(qr);

                if (res.next()) {
                    txtBname.setText(res.getString("book_name"));
                    txtBauthor.setText(res.getString("author"));
                    txtBprice.setText(res.getString("price"));
                    txtBID.setText(res.getString("BID"));

                } else {
                    boxShowErr1.setVisible(true);
                    txtBSearch.requestFocus();
                    Utils.clean(txtBID, txtBname, txtBauthor, txtBprice);
                }
            } else {
//                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Book ID is empty", "Please enter a valid ID and try again!");
                txtBID.requestFocus();
            }

        } catch (Exception ex) {
            
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Can't find the data", """
                          Check this:
                          [1]Check the inserted search text, search field can't be empty or any invalid characters.
                          [2]Check your database connecitvaty.
                          [3][5]Check your text fields (Fields shuould'nt be empty).
                          [4]The system error is: """ + ex.getMessage());
        }
    }

    @FXML
    private void searchStudent(ActionEvent event) {

        try {
            if (!txtSSearch.getText().trim().isEmpty()) {

                String title = txtSSearch.getText();
                String qr = "SELECT * FROM students WHERE s_name LIKE '" + title + "%'"
                        + " OR s_lname LIKE '" + title + "%' OR SID LIKE '" + title + "'";

                Statement stm = conn.createStatement();
                res = stm.executeQuery(qr);

                if (res.next()) {
                    txtSname.setText(res.getString("s_name") +  " '"+
                            res.getString("s_lname") + "'");
                    txtSID.setText(res.getString("SID"));

                } else {
                    boxShowErr2.setVisible(true);
                    txtSSearch.requestFocus();
                    Utils.clean(txtSID, txtSname);
                }
            } else {
//                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Search field is empty", "Please enter a searching title and try again!");
                txtSSearch.requestFocus();
            }
        } catch (Exception ex) {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Can't find the data", """
                        Check this:
                        [1]Check the inserted search text, search field can't be empty or any invalid characters.
                        [2]Check your database connecitvaty.
                        [3][5]Check your text fields (Fields shuould'nt be empty).
                        [4]The system error is:""" + ex.getMessage());
            
        }
    }

    // method for hidding hbox
    @FXML
    private void hideError(KeyEvent evt) {
        if (evt.getSource() == txtBSearch) {
            boxShowErr1.setVisible(false);
        } else if (evt.getSource() == txtSSearch) {
            boxShowErr2.setVisible(false);
        }

    }

    @FXML
    private void issueBook(ActionEvent event) {

        try {

            String qr = "INSERT INTO issues (BID, book_name, author,  SID, s_name, lname, DOI, DOR) VALUES (?, ?, ?, ?, ?,?, ?, ?)";
            pstm = DBConnect.getPstm(qr);

            pstm.setString(1, txtBID.getText());
            pstm.setString(2, txtBname.getText());
            pstm.setString(3, txtBauthor.getText());

            pstm.setString(4, txtSID.getText());
            pstm.setString(5, txtSname.getText().split("'")[0]);
            pstm.setString(6, txtSname.getText().split("'")[1]);

            pstm.setString(7, dtDate.getValue().toString());
            pstm.setString(8, dtDate2.getValue().toString());

            if (pstm.executeUpdate() == 1) {
                Utils.alertIt(Alert.AlertType.INFORMATION, "Issue", "SUCCESS", "Book successfuly issued to '" + txtSname.getText() + "'");
                Utils.clean(txtBauthor, txtBname, txtBprice, txtSname, txtSID, txtBID);
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Issue", "FAILED", "book not  issued to '" + txtSname.getText() + "'");

            }

        } catch (Exception ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Search", "FAILED", """
                            Check this:
                            [1]Check the inserted search text, search field can't be empty or any invalid characters.
                            [2]Check your database connecitvaty.
                            [3][5]Check your text fields (Fields shuould'nt be empty).
                            [4]The system error is: """ + ex.getMessage());
        }

    }

}

package LMS.utils;

import java.sql.*;
import javafx.scene.control.Alert;

/**
 *
 * @author Nooriallah
 */
public class DBConnect {

    static Connection conn;
    static PreparedStatement pstm;
    static ResultSet res;

    // method for connecting us to database
    public static Connection getConn(String url) {
        try {

            conn = DriverManager.getConnection("jdbc:mysql://localhost/" + url +"?user=root&password=");

        } catch (SQLException exp) {
            if(exp.getMessage().contains("Communications link failure")) {
               Utils.alertIt(Alert.AlertType.ERROR, "Connection", "Can't connect to database", "Check your database source, mybe you are offline.");
            }
            System.out.println(exp);
            System.exit(0);
            
        }
        return conn;
    }

    // Method for applying pstm statement
    public static PreparedStatement getPstm(String query) {
        try {
            pstm = conn.prepareStatement(query);
        } catch (SQLException ex) {
            System.out.println("getPSTM: " + ex);
        }
        return pstm;
    }

    // method for result set
    public static ResultSet getResult() {
        try {
            res =  pstm.executeQuery();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return res;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package LMS.returnBook;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import java.sql.*;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class ReturnbookController implements Initializable {

    @FXML
    private HBox boxShowErr2;
    @FXML
    private Label lblMsg2;
    @FXML
    private TextField txtSID;
    @FXML
    private TextField txtSname;
    @FXML
    private TextField txtBID;
    @FXML
    private TextField txtBname;
    @FXML
    private TextField txtBauthor;
    @FXML
    private TextField txtIsDt;
    @FXML
    private DatePicker dtDate1;
    @FXML
    private Button btnIReturn;

    Connection conn;
    ResultSet res;
    PreparedStatement pstm;
    private TextField txtLname;
    @FXML
    private TextField txtSSearch;
    @FXML
    private Button btnSearch11;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        dtDate1.setValue(java.time.LocalDate.now());
        boxShowErr2.setVisible(false);
    }

    @FXML
    private void hideError(KeyEvent event) {
        boxShowErr2.setVisible(false);
    }

    @FXML
    private void searchStudent(ActionEvent event) {
        try {
            if (!txtSSearch.getText().trim().isEmpty()) {

                String title = txtSSearch.getText();
                var qr = "SELECT * FROM issues WHERE SID LIKE '" + title + "' "
                        + "OR s_name LIKE '" + title + "%' "
                        + "OR lname LIKE '" + title + "%'";
                
                Statement stm = conn.createStatement();
                res = stm.executeQuery(qr);

                if (res.next()) {
                    txtSID.setText(res.getString("SID"));
                    txtSname.setText(res.getString("s_name") + " '"
                            + res.getString("lname") + "'");
                    
                    txtBID.setText(res.getString("BID"));
                    txtBname.setText(res.getString("book_name"));
                    txtBauthor.setText(res.getString("author"));
                    
                    txtIsDt.setText(res.getString("DOI"));

                } else {
                    boxShowErr2.setVisible(true);
                    txtSID.requestFocus();
                    Utils.clean(txtSname, txtSID, txtBname, txtBauthor, txtIsDt, txtBID);
                }
            } else {
//                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Student ID is empty", "Please enter a valid ID and try again!");
                txtSSearch.requestFocus();
            }
        } catch (Exception ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Search", "Can't find the data", """
                          Check this:
                          [1]Check the inserted search text, search field can't be empty or any invalid characters.
                          [2]Check your database connecitvaty.
                          [3][5]Check your text fields (Fields shuould'nt be empty).
                          [4]The system error is: """ + ex.getMessage());
        }
    }

    @FXML
    private void returnBook(ActionEvent event) {
        try {

            String qr = "INSERT INTO returnbooks (BID, book_name, author,  SID, s_name, lastname,  DOR) VALUES (?, ?, ?, ?, ?, ?,?)";
            pstm = DBConnect.getPstm(qr);

            pstm.setString(1, txtBID.getText());
            pstm.setString(2, txtBname.getText());
            pstm.setString(3, txtBauthor.getText());
            pstm.setString(4, txtSID.getText());
            pstm.setString(5, txtSname.getText().split("'")[0]);
            pstm.setString(6, txtSname.getText().split("'")[1]);
            pstm.setString(7, dtDate1.getValue().toString());

            if (pstm.executeUpdate() == 1) {
                deleteBook();
                Utils.alertIt(Alert.AlertType.INFORMATION, "Retrun", "SUCCESS", "Book successfuly return.");
                
                Utils.clean(txtSname, txtBname, txtSID, txtBID, txtBauthor, txtIsDt);

            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Issue", "FAILED", "book can not  return.");

            }

        } catch (Exception ex) {
            if (ex.getMessage().contains("Duplicate entry '" + txtBID.getText() + "-" + txtSID.getText() + "' for key 'PRIMARY'")) {
                Utils.alertIt(Alert.AlertType.WARNING, "Return", "FAILED", "Book already returned");
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Can't find the data", """
                          Check this:
                          [1]Check the inserted search text, search field can't be empty or any invalid characters.
                          [2]Check your database connecitvaty.
                          [3][5]Check your text fields (Fields shuould'nt be empty).
                          [4]The system error is: """ + ex.getMessage());
            }
        }
    }

    public void deleteBook() {
        try {

            int id = Integer.parseInt(txtBID.getText());
            pstm = conn.prepareStatement("DELETE FROM issues WHERE SID = ? AND BID = ?");
            pstm.setString(1, txtSID.getText());
            pstm.setString(2, txtBID.getText());

            pstm.executeUpdate();

        } catch (Exception ex) {
            if (ex.getMessage().contains("For input string: \"" + txtSID.getText() + "\"")) {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "ID is not valid", "Check the Inserted ID, ID can't be empty or character except number");
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "RETURN", "Can't find the data", """
                                                                                      Check this:
                                                                                      [1]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [2]Check your database connecitvaty.
                                                                                      [3]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [4][5]Check your text fields (Fields shuould'nt be empty).
                                                                                      [5]The error is: """ + ex.getMessage());
            }
        }
    }
}

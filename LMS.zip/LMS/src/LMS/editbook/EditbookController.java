
package LMS.editbook;

import LMS.allbook.AllbookController;
import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class EditbookController implements Initializable {

    @FXML
    private TextField txtBname;
    @FXML
    private TextField txtBNewName;
    @FXML
    private TextField txtBID;
    @FXML
    private TextField txtAuthor;
    @FXML
    private TextField txtPub;
    @FXML
    private ComboBox<String> cbxEdi;
    @FXML
    private TextField txtPrice;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnSearch;
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    @FXML
    private HBox boxShowErr1;
    @FXML
    private Label lblMsg1;
    @FXML
    private CheckBox chkEdit;
    @FXML
    private TextField txtQnt;
    
    
//    public EditbookController(int id) {
//        txtBID.setText(id+"");
//    }

    /** 
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        boxShowErr1.setVisible(false);
    }    

    
//   Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();

    @FXML
    private void searchBook(ActionEvent event) {
        ObservableList<String> edi = FXCollections.observableArrayList("1","2","3","4","5","6","7","8");
        try {
            if (!txtBname.getText().trim().isEmpty()) {
                String  title = txtBname.getText();
                String qr2 = "SELECT * FROM books WHERE book_name LIKE '" + title + "%'"
                        + " OR author LIKE '" + title + "%' "
                        + " OR BID LIKE '" + title + "'";
                
                Statement stm = conn.createStatement();
                res = stm.executeQuery(qr2);

                if (res.next()) {
                    txtBID.setText(res.getString("BID"));
                    txtBNewName.setText(res.getString("book_name"));
                    txtAuthor.setText(res.getString("author"));
                    txtPub.setText(res.getString("publisher"));
                    cbxEdi.setValue(res.getString("edition"));
                    txtQnt.setText(res.getString("quantity"));
                    txtPrice.setText(res.getString("price"));
                    
                    cbxEdi.setItems(edi);
                    
                } else {
                    boxShowErr1.setVisible(true);
                    txtBname.requestFocus();
                    Utils.clean(txtAuthor, txtQnt, txtBNewName, txtBID, txtPrice, txtPub);
                    cbxEdi.setValue("");
                }
            } else {
//                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Book ID is empty", "Please enter a valid ID and try again!");
                txtBname.requestFocus();
            }

        } catch (Exception ex) {
            if (ex.getMessage().contains("For input string: \"" + txtBID.getText() + "\"")) {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "ID is not valid", "Check the Inserted ID, ID can't be empty or character except number");
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "FAILED", """
                                                                                      Check this:
                                                                                      [1]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [2]Check your database connecitvaty.
                                                                                      [3]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [4][5]Check your text fields (Fields shuould'nt be empty).
                                                                                      [5]The error is: """ + ex.getMessage());
            }
        }
    }
    
    
    @FXML
    private void hideError(KeyEvent evt) {
        boxShowErr1.setVisible(false);
    }

    @FXML
    private void enableBIDfield(ActionEvent event) {
        if (chkEdit.isSelected()) txtBID.setEditable(true);
        else txtBID.setEditable(false);
    }
    
    @FXML
    private void updateBook(ActionEvent event) {
        
        try {
            int id = Integer.parseInt(txtBID.getText());
            
            String qr = "UPDATE books SET  book_name = ?,"
                    + "  author = ?, publisher = ?, edition = ?,"
                    + " price = ?, quantity = ?, BID = ?  WHERE BID = " + id;
            
            pstm = DBConnect.getPstm(qr);
            
            pstm.setString(1, txtBNewName.getText());
            pstm.setString(2, txtAuthor.getText());
            pstm.setString(3, txtPub.getText());
            pstm.setString(4, cbxEdi.getSelectionModel().getSelectedItem());
            pstm.setString(5, txtPrice.getText());
            pstm.setString(6, txtQnt.getText());
            pstm.setString(7, txtBID.getText());
            
            int ins = pstm.executeUpdate();
            if(ins > 0) {
                Utils.alertIt(Alert.AlertType.INFORMATION, "Update", "SUCCESS", "Book successfuly updatedt.");
                Utils.clean(txtAuthor, txtBNewName, txtQnt, txtBID, txtPub, txtPrice);
                cbxEdi.setValue("");
            }
            else {
                Utils.alertIt(Alert.AlertType.WARNING, "Update", "FAILED!", "Not update");
            }
            
        } catch (Exception ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Update", "ERROR", "Check this:\n"
                    + "[1]Check your database connecitvaty.\n"
                    + "[2]Check your text fields (Fields shuould'nt be empy).\n"
                    + "[3] Ceck value of text fields(Put valid value to text fields).");
        }
        
        
        
    }
    
}

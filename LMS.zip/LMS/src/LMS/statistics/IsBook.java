/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LMS.statistics;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author n094y
 */
public class IsBook {
    StringProperty bid, bname, author, sid, sname, lname, doi, dor, dor21;
    
    public IsBook() {
        this.bid   = new SimpleStringProperty();
        this.bname = new SimpleStringProperty();
        this.lname = new SimpleStringProperty();
        this.author= new SimpleStringProperty();
        this.sid= new SimpleStringProperty();
        this.sname = new SimpleStringProperty();
        this.lname  = new SimpleStringProperty();
        this.doi = new SimpleStringProperty();
        this.dor = new SimpleStringProperty();
        this.dor21 = new SimpleStringProperty();
        
    }

    public StringProperty getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid.set(bid);
    }

    public StringProperty getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname.set(bname);
    }

    public StringProperty getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author.set(author);
    }

    public StringProperty getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid.set(sid);
    }

    public StringProperty getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname.set(sname);
    }

    public StringProperty getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname.set(lname);
    }

    public StringProperty getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi.set(doi);
    }

    public StringProperty getDor() {
        return dor;
    }

    public void setDor(String dor) {
        this.dor.set(dor);
    }

    public StringProperty getDor21() {
        return dor21;
    }

    public void setDor21(String dor21) {
        this.dor21.set(dor21);
    }
    
    
}

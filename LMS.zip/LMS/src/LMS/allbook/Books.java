/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LMS.allbook;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author n094y
 */
public class Books {
    StringProperty bid, bname, author, edition, quantity, price;

    public Books() {
        bid = new SimpleStringProperty(this, "BID");
        bname = new SimpleStringProperty(this, "book_name");
        author = new SimpleStringProperty(this, "author");
        edition = new SimpleStringProperty(this, "edition");
        price = new SimpleStringProperty(this, "price");
        quantity = new SimpleStringProperty(this, "price");
    }

    public StringProperty getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid.set(bid);
    }

    public StringProperty getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname.set(bname);
    }

    public StringProperty getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author.set(author);
    }

    public StringProperty getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition.set(edition);
    }
    public StringProperty getQuantity() {
        return quantity;
    }

    public void setQuantity(String qnt) {
        this.quantity.set(qnt);
    }

    public StringProperty getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }
    
    
    
    
}

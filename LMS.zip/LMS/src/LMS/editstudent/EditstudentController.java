/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package LMS.editstudent;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class EditstudentController implements Initializable {

    ObservableList<String> branch, course, year, semis;
    Connection conn;
    PreparedStatement pstm;
    ResultSet res;

    @FXML
    private HBox boxShowErr1;
    @FXML
    private Label lblMsg1;
    @FXML
    private Button btnSearch;
    @FXML
    private TextField txtSname;
    @FXML
    private TextField txtSlname;
    @FXML
    private ComboBox cbxBranch;
    @FXML
    private ComboBox cbxCourse;
    @FXML
    private ComboBox cbxYear;
    @FXML
    private ComboBox cbxSemister;
    @FXML
    private Button btnUpdate;
    @FXML
    private TextField txtSID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        boxShowErr1.setVisible(false);
    }

//    =================================================
    @FXML
    private void searchStudent(ActionEvent event) {
        ObservableList<String> br = FXCollections.observableArrayList("BCS", "BBA", "LLB");
        ObservableList<String> yr = FXCollections.observableArrayList("1st", "2nd", "3rd", "4th");
        ObservableList<String> sm = FXCollections.observableArrayList("1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th");

        try {
            if (!txtSID.getText().trim().isEmpty()) {

                int id = Integer.parseInt(txtSID.getText());
                var qr = "SELECT * FROM students WHERE SID = " + id;
                Statement stm = conn.createStatement();
                res = stm.executeQuery(qr);

                if (res.next()) {
                    txtSname.setText(res.getString("s_name"));
                    txtSlname.setText(res.getString("s_lname"));
                    cbxBranch.setValue(res.getString("branch"));
                    cbxCourse.setValue(res.getString("course"));
                    cbxYear.setValue(res.getString("year"));
                    cbxSemister.setValue(res.getString("semister"));

                    cbxBranch.setItems(br);
                    cbxYear.setItems(yr);
                    cbxSemister.setItems(sm);

                } else {
                    boxShowErr1.setVisible(true);
                    txtSID.requestFocus();
                    Utils.clean(txtSlname, txtSname);
                    cbxBranch.setValue("");
                    cbxCourse.setValue("");
                    cbxSemister.setValue("");
                    cbxYear.setValue("");
                }
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Student ID is empty", "Please enter a valid ID and try again!");
                txtSID.requestFocus();
            }
        } catch (Exception ex) {
            if (ex.getMessage().contains("For input string: \"" + txtSID.getText() + "\"")) {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "ID is not valid", "Check the Inserted ID, ID can't be empty or character except number");
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Search", "Can't find the data", """
                                                                                      Check this:
                                                                                      [1]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [2]Check your database connecitvaty.
                                                                                      [3]Check the Inserted ID, ID can't be empty or character except number
                                                                                      [4][5]Check your text fields (Fields shuould'nt be empty).
                                                                                      [5]The error is: """ + ex.getMessage());
            }
        }
    }

    @FXML
    private void updateStud(ActionEvent event) {
        try {
            int id = Integer.parseInt(txtSID.getText());
            String qr = "UPDATE students SET  s_name = ?, s_lname=?, branch=?, course=?, year=?, semister=?WHERE SID =" + id;

            pstm = DBConnect.getPstm(qr);

            pstm.setString(1, txtSname.getText());
            pstm.setString(2, txtSlname.getText());
            pstm.setString(3, cbxBranch.getSelectionModel().getSelectedItem().toString());
            pstm.setString(4, cbxCourse.getSelectionModel().getSelectedItem().toString());
            pstm.setString(5, cbxYear.getSelectionModel().getSelectedItem().toString());
            pstm.setString(6, cbxSemister.getSelectionModel().getSelectedItem().toString());

            int ins = pstm.executeUpdate();
            if (ins > 0) {
                Utils.alertIt(Alert.AlertType.INFORMATION, "Update", "SUCCESS", "Student successfuly updated.");

            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Udate", "FAILED", "Can't update student");
            }
            Utils.clean(txtSname, txtSlname);
            cbxBranch.setValue("");
            cbxCourse.setValue("");
            cbxSemister.setValue("");
            cbxYear.setValue("");

        } catch (Exception ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Update", "ERROR", "Check this:\n"
                    + "[1]Check your database connecitvaty.\n"
                    + "[2]Check your text fields (Fields shuould'nt be empty).\n"
                    + "[3] Ceck the value of dropdowns(select a valid value to dropdowns).");
        }
    }

    @FXML
    private void onBrachChange(ActionEvent event) {
        switch (cbxBranch.getSelectionModel().getSelectedIndex()) {
            case 0 -> {
                course = FXCollections.observableArrayList("SE", "IT", "Security");
                cbxCourse.setItems(course);
            }
            case 1 -> {
                course = FXCollections.observableArrayList("Markating", "Busseniss");
                cbxCourse.setItems(course);
            }
            default -> {
                course = FXCollections.observableArrayList("");
                cbxCourse.setItems(course);
            }
        }
    }

    @FXML
    private void onYearChange(ActionEvent event) {
        switch (cbxYear.getSelectionModel().getSelectedIndex()) {
            case 0 -> {
                semis = FXCollections.observableArrayList("1st", "2nd");
                cbxSemister.setItems(semis);

            }
            case 1 -> {
                semis = FXCollections.observableArrayList("3rd", "4th");
                cbxSemister.setItems(semis);
            }
            case 2 -> {
                semis = FXCollections.observableArrayList("5th", "6th");
                cbxSemister.setItems(semis);
            }
            case 3 -> {
                semis = FXCollections.observableArrayList("7th", "8th");
                cbxSemister.setItems(semis);
            }
            default -> {
                semis = FXCollections.observableArrayList("");
                cbxSemister.setItems(semis);
            }

        }
    }

    @FXML
    private void hideError(KeyEvent evt) {
        boxShowErr1.setVisible(false);
    }

}

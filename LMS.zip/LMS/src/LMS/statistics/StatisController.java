package LMS.statistics;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class StatisController implements Initializable {

    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    IsBook isBook, retBook;
    @FXML
    private TableView<IsBook> tblIsBook;
    @FXML
    private TableColumn<IsBook, String> colBID1;
    @FXML
    private TableColumn<IsBook, String> colBname1;
    @FXML
    private TableColumn<IsBook, String> colAuth1;
    @FXML
    private TableColumn<IsBook, String> colSID1;
    @FXML
    private TableColumn<IsBook, String> colSname1;
    @FXML
    private TableColumn<IsBook, String> colLname1;
    @FXML
    private TableColumn<IsBook, String> colDOI1;
    @FXML
    private TableView<IsBook> tblRetBook;
    @FXML
    private TableColumn<IsBook, String> colBID2;
    @FXML
    private TableColumn<IsBook, String> colBname2;
    @FXML
    private TableColumn<IsBook, String> colAuth2;
    @FXML
    private TableColumn<IsBook, String> colSID2;
    @FXML
    private TableColumn<IsBook, String> colSname2;
    @FXML
    private TableColumn<IsBook, String> colLname2;
    @FXML
    private TableColumn<IsBook, String> colDOR2;
    @FXML
    private Label lblBook;
    @FXML
    private Label lblStu;
    @FXML
    private Label lblIssu;
    @FXML
    private Label lblRet;
    int book = 0, stu = 0, issu = 0, ret = 0;
    @FXML
    private TableColumn<IsBook, String> colDOR21;
    @FXML
    private MenuItem ctmRetBook;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        showAllBooks();
        showAllStu();
        showIssued();
        showReturned();
    }
//    ========================================================

    // show all books
    public void showAllBooks() {
        try {
            pstm = DBConnect.getPstm("SELECT * FROM books");
            res = DBConnect.getResult();
            while (res.next()) {
                book++;
            }
            lblBook.setText(book + "");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    // show all students 
    public void showAllStu() {
        try {
            pstm = DBConnect.getPstm("SELECT * FROM students");
            res = DBConnect.getResult();
            while (res.next()) {
                stu++;
            }
            lblStu.setText(stu + "");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

//    issued books 
    public void showIssued() {
        ObservableList records = FXCollections.observableArrayList();
        try {

            pstm = DBConnect.getPstm("SELECT * FROM issues");
            res = DBConnect.getResult();

            if (res.next()) {
                do {
                    isBook = new IsBook();
                    isBook.setBid(res.getString("BID"));
                    isBook.setBname(res.getString("book_name"));
                    isBook.setAuthor(res.getString("author"));
                    isBook.setSid(res.getString("SID"));
                    isBook.setSname(res.getString("s_name"));
                    isBook.setLname(res.getString("lname"));
                    isBook.setDoi(res.getString("DOI"));
                    isBook.setDor21(res.getString("DOR"));

                    records.addAll(isBook);
                    issu++;
                } while (res.next());
                lblIssu.setText(issu + "");
            }

            initColos();

            tblIsBook.setItems(records);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void initColos() {
        colBID1.setCellValueFactory(e -> e.getValue().getBid());
        colBname1.setCellValueFactory(e -> e.getValue().getBname());
        colAuth1.setCellValueFactory(e -> e.getValue().getAuthor());
        colSID1.setCellValueFactory(e -> e.getValue().getSid());
        colSname1.setCellValueFactory(e -> e.getValue().getSname());
        colLname1.setCellValueFactory(e -> e.getValue().getLname());
        colDOI1.setCellValueFactory(e -> e.getValue().getDoi());
        colDOR2.setCellValueFactory(e -> e.getValue().getDor());
        colDOR21.setCellValueFactory(e -> e.getValue().getDor21());

        // =================
        
        colBID2.setCellValueFactory(e -> e.getValue().getBid());
        colBname2.setCellValueFactory(e -> e.getValue().getBname());
        colAuth2.setCellValueFactory(e -> e.getValue().getAuthor());
        colSID2.setCellValueFactory(e -> e.getValue().getSid());
        colSname2.setCellValueFactory(e -> e.getValue().getSname());
        colLname2.setCellValueFactory(e -> e.getValue().getLname());
        colDOR2.setCellValueFactory(e -> e.getValue().getDoi());

    }

//    returned books table
    public void showReturned() {
        ObservableList records = FXCollections.observableArrayList();
        try {

            pstm = DBConnect.getPstm("SELECT * FROM returnbooks");
            res = DBConnect.getResult();
            if (res.next()) {
                do {
                    retBook = new IsBook();
                    retBook.setBid(res.getString("BID"));
                    retBook.setBname(res.getString("book_name"));
                    retBook.setAuthor(res.getString("author"));
                    retBook.setSid(res.getString("SID"));
                    retBook.setSname(res.getString("s_name"));
                    retBook.setLname(res.getString("lastname"));
                    retBook.setDoi(res.getString("DOR"));

                    records.addAll(retBook);
                    ret++;
                } while (res.next());
                lblRet.setText(ret + "");
            }

            initColos();

            tblRetBook.setItems(records);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @FXML
    private void retBook(ActionEvent event) {
        new Utils().showStage("Return Book", "/LMS/returnBook/returnbook.fxml");
    }

}

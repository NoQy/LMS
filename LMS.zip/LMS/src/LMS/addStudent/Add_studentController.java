/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package LMS.addStudent;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import java.sql.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class Add_studentController implements Initializable {

    ObservableList<String> branch, course, year, semis;

    @FXML
    private TextField txtSID;
    @FXML
    private TextField txtSname;
    @FXML
    private TextField txtSlname;
    @FXML
    private ComboBox cbxBranch;
    @FXML
    private ComboBox cbxCourse;
    @FXML
    private ComboBox cbxYear;
    @FXML
    private ComboBox cbxSemister;
    @FXML
    private Button btnIssue;

    Connection conn;
    PreparedStatement pstm;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
            // TODO
            conn = (Connection) DBConnect.getConn("lms2");
            initCbx();
            
            txtSID.setText(new Random().nextInt(10000+1)+"");
            
    }

    @FXML
    private void addStudent(ActionEvent event) {

        try {
            String qr = "INSERT INTO students (SID, s_name, s_lname, branch, course, year, semister) VALUES (?, ?, ?, ?, ?, ?, ?)";

            pstm = DBConnect.getPstm(qr);

            pstm.setString(1, txtSID.getText());
            pstm.setString(2, txtSname.getText());
            pstm.setString(3, txtSlname.getText());
            pstm.setString(4, cbxBranch.getSelectionModel().getSelectedItem().toString());
            pstm.setString(5, cbxCourse.getSelectionModel().getSelectedItem().toString());
            pstm.setString(6, cbxYear.getSelectionModel().getSelectedItem().toString());
            pstm.setString(7, cbxSemister.getSelectionModel().getSelectedItem().toString());

            int ins = pstm.executeUpdate();
            if (ins > 0) {
                Utils.alertIt(Alert.AlertType.INFORMATION, "Adding Student", "Student successfuly added!", "Now you can, issue book for this stuent.");
                Utils.clean(txtSname, txtSlname, txtSID);
                txtSname.requestFocus();
            } else {
                Utils.alertIt(Alert.AlertType.ERROR, "Adding student", "Not add", "student not please check your sql command");
            }

        } catch (Exception ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Inserting data", "Can't insert data", "Check this:\n"
                    + "[1]Check your database connecitvaty.\n"
                    + "[2]Check your text fields (Fields shuould'nt be empty).\n"
                    + "[3] Ceck the value of dropdowns(select a valid value to dropdowns).");
        }

    }

    // Method to declare combo boxes
    public void initCbx() {

        // first for branchs and courses
        branch = FXCollections.observableArrayList("BCS", "BBA", "LLB");
        cbxBranch.getItems().addAll(branch);
        cbxBranch.setValue("Enter branch of studying");

        // this is for year and semister
        year = FXCollections.observableArrayList("1st", "2nd", "3rd", "4th");
        cbxYear.getItems().addAll(year);
        cbxYear.setValue("Enter Year");

        semis = FXCollections.observableArrayList("1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th");

    }

    @FXML
    private void onBrachChange(ActionEvent event) {

        switch (cbxBranch.getSelectionModel().getSelectedIndex()) {
            case 0 -> {
                course = FXCollections.observableArrayList("SE", "IT", "Security");
                cbxCourse.setItems(course);
            }
            case 1 -> {
                course = FXCollections.observableArrayList("Markating", "Busseniss");
                cbxCourse.setItems(course);
            }
            default -> {
                course = FXCollections.observableArrayList("");
                cbxCourse.setItems(course);
            }
        }

    }

    @FXML
    private void onYearChange(ActionEvent event) {

        switch (cbxYear.getSelectionModel().getSelectedIndex()) {
            case 0 -> {
                semis = FXCollections.observableArrayList("1st", "2nd");
                cbxSemister.setItems(semis);

            }
            case 1 -> {
                semis = FXCollections.observableArrayList("3rd", "4th");
                cbxSemister.setItems(semis);
            }
            case 2 -> {
                semis = FXCollections.observableArrayList("5th", "6th");
                cbxSemister.setItems(semis);
            }
            case 3 -> {
                semis = FXCollections.observableArrayList("7th", "8th");
                cbxSemister.setItems(semis);
            }
            default -> {
                semis = FXCollections.observableArrayList("");
                cbxSemister.setItems(semis);
            }

        }
    }

}

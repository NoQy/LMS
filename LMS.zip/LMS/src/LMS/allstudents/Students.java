/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LMS.allstudents;

import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author n094y
 */
public class Students {
    StringProperty sid, name, lname, branch, course, year, semis;

    public Students() {
        this.sid   = new SimpleStringProperty();
        this.name = new SimpleStringProperty();
        this.lname = new SimpleStringProperty();
        this.branch= new SimpleStringProperty();
        this.course= new SimpleStringProperty();
        this.year  = new SimpleStringProperty();
        this.semis = new SimpleStringProperty();
    }

    public StringProperty getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid.set(sid);
    }

    public StringProperty getName() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname.set(lname);
    }

    public StringProperty getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch.set(branch);
    }

    public StringProperty getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course.set(course);
    }

    public StringProperty getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year.set(year);
    }

    public StringProperty getSemis() {
        return semis;
    }

    public void setSemis(String semis) {
        this.semis.set(semis);
    }
    
    
    
}

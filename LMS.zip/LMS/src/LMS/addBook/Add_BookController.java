
package LMS.addBook;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.print.Collation;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import java.sql.*;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class Add_BookController implements Initializable {

    @FXML
    private TextField txtBID;
    @FXML
    private TextField txtBname;
    @FXML
    private TextField txtBauthor;
    @FXML
    private TextField txtBpub;
    @FXML
    private ComboBox<String> cbxBedi;
    @FXML
    private TextField txtBprice;
    @FXML
    private Button btnIssue;
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    @FXML
    private TextField txtQnt;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ObservableList<String> items = FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8");
        cbxBedi.setItems(items);
        conn = DBConnect.getConn("lms2");
        txtBID.setText(new Random().nextInt(1000+1)+"");
    }    

    

    @FXML
    private void addBook(ActionEvent event) {
        try {
            String qr = "INSERT INTO books (BID, book_name, author, publisher, edition, quantity, price)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            pstm = DBConnect.getPstm(qr);
            
            pstm.setString(1, txtBID.getText());
            pstm.setString(2, txtBname.getText());
            pstm.setString(3, txtBauthor.getText());
            pstm.setString(4, txtBpub.getText());
            pstm.setString(5, cbxBedi.getSelectionModel().getSelectedItem());
            pstm.setString(6, txtQnt.getText());
            pstm.setString(7, txtBprice.getText());
            
            int ins = pstm.executeUpdate();
            if(ins > 0) {
                Utils.alertIt(Alert.AlertType.INFORMATION, "Insert Data", "SUCCESS", 
                        "The '" + txtBname.getText() +"'"
                         + " successfuly added, Now you can issue it.");
                
                Utils.clean(txtBID, txtBauthor, txtBname, txtBprice, txtBpub, txtQnt);
                txtBID.setText(new Random().nextInt(1000+1)+"");
                txtBname.requestFocus();
            }
            else {
                Utils.alertIt(Alert.AlertType.WARNING, "Insert Data", "FIALED!", "");
            }
            
        } catch (SQLException ex) {
            Utils.alertIt(Alert.AlertType.ERROR, "Inserting data", "Can't insert data", "Check this:\n"
                    + "[1]Check your database connecitvaty.\n"
                    + "[2]Check your text fields (Fields shuould'nt be empy).\n"
                    + "[3] Ceck value of text fields(Put valid value to text fields).\n"
                    + "[4] Error: " + ex.getMessage());
        }
        
        
    }

    
}

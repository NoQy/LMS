package LMS.utils;

import LMS.allbook.Books;
import LMS.allstudents.Students;
import java.awt.Color;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Optional;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Nooriallah
 */
public class Utils {

//    A greate method for searching data in a table view 
    public static void searchStudent(ObservableList list, TableView table, TextField txtSearch) {
        FilteredList<Students> filter = new FilteredList<>(list, evt -> true);
        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {

            filter.setPredicate( (emp) -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                
                String lowerCase = newValue.toLowerCase();
                if (emp.getSid().toString().contains(lowerCase)) {
                    return true;
                } else if (emp.getName().toString().toLowerCase().contains(lowerCase)) {
                    return true;
                } else if (emp.getLname().toString().toLowerCase().contains(lowerCase)) {
                    return true;
                }
                else {
                    return false;
                }

            });
        });

        SortedList<Students> sort = new SortedList<>(filter);
        sort.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sort);

    }
    
    public static void searchBook(ObservableList list, TableView table, TextField txtSearch) {
        FilteredList<Books> filter = new FilteredList<>(list, evt -> true);
        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {

            filter.setPredicate( (emp) -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                
                String lowerCase = newValue.toLowerCase();
                if (emp.getBid().toString().contains(lowerCase)) {
                    return true;
                } else if (emp.getBname().toString().toLowerCase().contains(lowerCase)) {
                    return true;
                } else if (emp.getAuthor().toString().toLowerCase().contains(lowerCase)) {
                    return true;
                }
                else {
                    return false;
                }

            });
        });

        SortedList<Books> sort = new SortedList<>(filter);
        sort.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sort);

    }

    
    
    // method for alert
    public static void alertIt(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setHeaderText(header);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static Optional<ButtonType> getAlert(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setHeaderText(header);
        alert.setTitle(title);
        alert.setContentText(content);
        Optional<ButtonType> ans = alert.showAndWait();
        return ans;
    }

//    method for validation of forms
    public static boolean isValid(String... value) {
        boolean v;

        if (value[0].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[1].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[2].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[3].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[4].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[5].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else if (value[6].trim().isEmpty()) {
            alertIt(Alert.AlertType.ERROR, "Empty Field", "Some field(s) is/are empty", "Empty");
            v = false;
        } else {
            v = true;
        }

        return v;
    }

    //    Method for show error in a label
    public static void showLbl(Label lbl, boolean vis, String text) {
        lbl.setVisible(vis);
        lbl.setText(text);
    }

    //method for cleaning text fields
    public static void clean(TextField... txt) {
        for (TextField txt1 : txt) {
            txt1.setText("");
        }

    }

//    method for showing stage
    public void showStage(String title, String path) {
        try {
            Stage stage = new Stage();

            Parent root = FXMLLoader.load(this.getClass().getResource(path));
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setResizable(false);
            stage.setTitle(title);
            stage.centerOnScreen();
            stage.show();

        } catch (IOException ex) {
            System.out.println("show Stage: " + ex.getMessage());
        }
    }

}

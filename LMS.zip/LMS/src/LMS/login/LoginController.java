/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package LMS.login;

import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class LoginController implements Initializable {

    @FXML
    private Circle cricle;
    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField psPassword;
    @FXML
    private Button btnLogin;
    @FXML
    private Label lblErr;
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    @FXML
    private Pane pnlLogin;
    Utils utils;
    @FXML
    private AnchorPane ancLogin;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        cricle.setFill(new ImagePattern(new Image("/LMS/img/second.jpg")));
        conn = DBConnect.getConn("lms2");
        utils = new Utils();
    }    
    
    
    
    
    @FXML
    public void doLogin() throws SQLException, IOException {
        
        String qr = "SELECT * FROM admins WHERE username = ? AND password = ?";
        
        pstm = DBConnect.getPstm(qr);
        
        pstm.setString(1, txtUsername.getText().trim());
        pstm.setString(2, psPassword.getText().trim());
        
        res = DBConnect.getResult();
        
        if(res.next()) {
                Stage st = (Stage)btnLogin.getScene().getWindow();
                Parent root = FXMLLoader.load(getClass().getResource("/LMS/main/main.fxml"));
                Scene sn = new Scene(root);
                st.setTitle("Library Management System");
                st.setResizable(false);
                st.setScene(sn);
                st.show();
                
        }
        else {
            lblErr.setVisible(true);
        }        
    }
    
   

    @FXML
    private void clearErr(KeyEvent event) {
//        System.out.println(event.getSource());
        
        if(event.getCode().toString().equals("ENTER")) {
            if(event.getSource() == txtUsername){
                psPassword.requestFocus();
            }
                
            else if(event.getSource() == psPassword){
                btnLogin.requestFocus();
                btnLogin.fire();
            }
        }
        lblErr.setVisible(false);

    }
}

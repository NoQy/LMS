package LMS.allbook;

import LMS.editbook.EditbookController;
import LMS.utils.DBConnect;
import LMS.utils.Utils;
import java.awt.print.Book;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.*;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author n094y
 */
public class AllbookController implements Initializable {

    @FXML
    private TableView<Books> tblBooks;
    @FXML
    private TableColumn<Books, String> colBID;
    @FXML
    private TableColumn<Books, String> colBname;
    @FXML
    private TableColumn<Books, String> colAuthor;
    @FXML
    private TableColumn<Books, String> colEditon;
    @FXML
    private TableColumn<Books, String> colPrice;
    @FXML
    private TableColumn<Books, String> colQnt;
    
    Books allBooks;

    Connection conn;
    PreparedStatement pstm;
    ResultSet res;
    
    @FXML
    private MenuItem cmEdit;
    @FXML
    private MenuItem cmDelete;
    @FXML
    private TextField txtSearch;
    @FXML
    private MenuItem cmIssue;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        conn = DBConnect.getConn("lms2");
        showAllBooks();
        
       
    }

    public void showAllBooks() {
        ObservableList records = FXCollections.observableArrayList();
        try {

            pstm = DBConnect.getPstm("SELECT BID, book_name, author, edition, quantity, price FROM books");
            res = DBConnect.getResult();
            
            if (res.next()) {
                do {
                    allBooks = new Books();
                    allBooks.setBid(res.getString("BID"));
                    allBooks.setBname(res.getString("book_name"));
                    allBooks.setAuthor(res.getString("author"));
                    allBooks.setEdition(res.getString("edition"));
                    allBooks.setQuantity(res.getString("quantity"));
                    allBooks.setPrice(res.getString("price"));

                    records.addAll(allBooks);
                }
                while (res.next());
            }

            colBID.setCellValueFactory(e -> e.getValue().getBid());
            colBname.setCellValueFactory(e -> e.getValue().getBname());
            colAuthor.setCellValueFactory(e -> e.getValue().getAuthor());
            colEditon.setCellValueFactory(e -> e.getValue().getEdition());
            colQnt.setCellValueFactory(e -> e.getValue().getQuantity());
            colPrice.setCellValueFactory(e -> e.getValue().getPrice());

            tblBooks.setItems(records);
            Utils.searchBook(records, tblBooks, txtSearch);

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    
    
    @FXML
    private void deleteBook(ActionEvent event) {
        try {
            if (tblBooks.getSelectionModel().getSelectedIndex() > -1) {
                int id = Integer.parseInt(tblBooks.getSelectionModel().getSelectedItem().getBid().getValueSafe());
                pstm = DBConnect.getPstm("DELETE FROM books WHERE BID = " + id);

                Optional<ButtonType> alt = Utils.getAlert(Alert.AlertType.CONFIRMATION, "DELETE" , "Are you sure ?", "Do you want to delete this book premenetly ? ");
                if (alt.get() == ButtonType.OK) {
                    
                    int del = pstm.executeUpdate();
                    if (del > 0) {
//                        Utils.alertIt(Alert.AlertType.INFORMATION, "DELETE", "Deleted", "The book premenently deleted!");
                        showAllBooks();
                        
                    } else {
                        Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "Not Deleted", "Check your database conectivity");
                    }
                }
            }

        } catch (Exception ex) {
            if (ex.getMessage().contains("foreign key")) {
                Utils.alertIt(Alert.AlertType.ERROR, "DELETE", "Not Deleted", "This book is already issued, First return the book and try again.");
            }
            else {
                System.out.println(ex);
            }
            
        }
    }


    @FXML
    private void updateBook(ActionEvent event) {
        new Utils().showStage("Update Book", "/LMS/editbook/editbook.fxml");
    }

    @FXML
    private void issueBook(ActionEvent event) {
        new Utils().showStage("Issue Book", "/LMS/issue/issue.fxml");

    }

    
}
